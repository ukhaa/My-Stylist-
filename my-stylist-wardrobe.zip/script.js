document.getElementById("uploadForm").addEventListener("submit", function (e) {
  e.preventDefault();
  const input = document.getElementById("fileInput");
  const gallery = document.getElementById("gallery");

  if (input.files) {
    for (let file of input.files) {
      const reader = new FileReader();
      reader.onload = function (e) {
        const img = document.createElement("img");
        img.src = e.target.result;
        img.className = "wardrobe-img";
        gallery.appendChild(img);
      };
      reader.readAsDataURL(file);
    }
  }
});
